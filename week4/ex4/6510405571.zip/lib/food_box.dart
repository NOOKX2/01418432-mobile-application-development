import 'package:ex4/food_detail.dart';
import 'package:flutter/material.dart';

class FoodBox extends StatelessWidget {
  const FoodBox({
    super.key,
    required this.name,
    required this.price,
    required this.image,
  });

  final String name;
  final int price;
  final String image;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => FoodDetail(
            name: name,
            price: price,
            image: image,
          )),
        );
      },
      child: Container(
        padding: EdgeInsets.all(2),
        height: 120,
        child: Card(
          child: Stack(
            alignment: Alignment.center,
            children: [
              Column(
                children: <Widget>[
                  const SizedBox(height: 2),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(55),
                    child: Image.asset(
                      'assets/$image',
                      height: 110,
                      width: 110,
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      children: [
                        Text(name),
                        Text(
                          price.toString(),
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Icon(Icons.favorite, color: Colors.red),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

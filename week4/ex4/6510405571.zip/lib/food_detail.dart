import 'package:flutter/material.dart';

class FoodDetail extends StatelessWidget {
  const FoodDetail({
    super.key,
    required this.name,
    required this.price,
    required this.image,
  });

  final String name;
  final int price;
  final String image;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
      ),
      body: Center(
        child: Column(
          spacing: 20,
          children: [
            ClipRRect(child: Image.asset('assets/$image', height: 350, width: double.infinity, fit: BoxFit.cover,)),
            //const SizedBox(height: 50),
            Padding(
              padding: const EdgeInsetsGeometry.all(20),
              child: Column(
                spacing: 20,
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '${price.toString()} ฿',
                    style: TextStyle(fontSize: 22, color: Colors.red, fontWeight: FontWeight.bold),
                  ),
                
                  Text(
                    "Enjoy our delicious $name, made with the freshest ingredients and prepared with love. A perfect choice for your meal today!",
                    style: TextStyle(color: Colors.grey[600], height: 1.5, fontSize: 18),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:ex4/food_box.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: const Color.fromARGB(255, 244, 238, 238),
            pinned: true,
            floating: false,
            title: Text(
              title,
              style: GoogleFonts.lato(
                color: Colors.black,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(1),

              child: Container(
                color: const Color.fromARGB(255, 191, 181, 181),
                height: 1,
              ),
            ),
            actions: [
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.shopping_cart_outlined),
              ),
            ],
          ),

          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1,
              ),
              delegate: SliverChildListDelegate([
                FoodBox(name: 'Mcdonald Burger', price: 200,image: 'mcdonald_burger.avif',),
                FoodBox(name: 'Pizza Signature', price: 300,image: 'pizza_signature.avif',),
                FoodBox(name: 'Dairy Queen',price: 20,image: 'dairy_queen.webp',),
                FoodBox(name: 'Steak', price: 250, image: 'steak.avif'),
                FoodBox(name: 'Salad', price: 150, image: 'salad.avif'),
                FoodBox(name: 'Pancake', price: 150, image: 'pancake.avif'),
                FoodBox(name: 'Fried Egg', price: 50, image: 'fried_egg.avif'),
                FoodBox(name: 'Tom Yum Kung',price: 150,image: 'tom_yum_kung.jpg',),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
